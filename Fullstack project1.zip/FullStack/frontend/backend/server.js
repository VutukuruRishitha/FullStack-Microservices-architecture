const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(express.json());
app.use(cors());

// Serve frontend folder
app.use(express.static(path.join(__dirname, "frontend")));

// Serve index.html at root
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "frontend", "index.html"));
});

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Rishitha@173", // <-- your MySQL password
  database: "eventora"
});

db.connect(err => {
  if (err) {
    console.error("DB connection error:", err);
  } else {
    console.log("MySQL Connected ✅");
  }
});

// Register user
app.post("/register", (req, res) => {
  const { username, password } = req.body;
  db.query(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    [username, password],
    (err) => {
      if (err) return res.json({ error: err.message });
      res.json({ message: "User registered" });
    }
  );
});

// Login user
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  db.query(
    "SELECT * FROM users WHERE username=? AND password=?",
    [username, password],
    (err, result) => {
      if (err) return res.json({ error: err.message });
      if (result.length > 0) res.json({ success: true });
      else res.json({ success: false });
    }
  );
});

// Book event
app.post("/book", (req, res) => {
  const { name, ticketId, date } = req.body;
  db.query(
    "INSERT INTO bookings (name, ticketId, date) VALUES (?, ?, ?)",
    [name, ticketId, date],
    (err) => {
      if (err) return res.json({ error: err.message });
      res.json({ message: "Booked" });
    }
  );
});

// Get booking history
app.get("/history", (req, res) => {
  db.query("SELECT * FROM bookings", (err, results) => {
    if (err) return res.json({ error: err.message });
    res.json(results);
  });
});

// Start server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
  
  // Automatically open the website in the default browser (Windows)
  require("child_process").exec('start http://localhost:3000');
});