const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Rishitha@173'
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    process.exit(1);
  }
  console.log('Connected to MySQL server.');

  // Create database
  connection.query('CREATE DATABASE IF NOT EXISTS eventora', (err) => {
    if (err) {
      console.error('Error creating database:', err);
      process.exit(1);
    }
    console.log('Database `eventora` created or already exists.');

    // Switch to the newly created database
    connection.changeUser({ database: 'eventora' }, (err) => {
      if (err) {
        console.error('Error switching to `eventora` database:', err);
        process.exit(1);
      }
      console.log('Switched to `eventora` database.');

      // Create users table
      const createUsersTableQuery = `
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          username VARCHAR(255) NOT NULL UNIQUE,
          password VARCHAR(255) NOT NULL
        )
      `;

      connection.query(createUsersTableQuery, (err) => {
        if (err) {
          console.error('Error creating `users` table:', err);
          process.exit(1);
        }
        console.log('Table `users` created or already exists.');

        // Create bookings table
        const createBookingsTableQuery = `
          CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            ticketId VARCHAR(255) NOT NULL,
            date VARCHAR(255) NOT NULL
          )
        `;

        connection.query(createBookingsTableQuery, (err) => {
          if (err) {
            console.error('Error creating `bookings` table:', err);
            process.exit(1);
          }
          console.log('Table `bookings` created or already exists.');

          // Close connection
          connection.end();
          console.log('Database setup complete. Connection closed.');
        });
      });
    });
  });
});
